import logo from './logo.svg';
import './App.css';
import Login from './components/Login';
import { useNavigate } from 'react-router-dom';
import { Route, BrowserRouter,Routes } from 'react-router-dom';
import { useEffect } from 'react';
import Home from './components/Home';

function App() {

  

  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route path="/" replace element={<Login />} />
        {/* </Routes>
        <Routes> */}
          <Route path="/home" element={<Home />} />
        </Routes>
        </BrowserRouter>
    </div>
  );
}

export default App;
