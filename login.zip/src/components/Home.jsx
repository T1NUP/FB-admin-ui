import React,{useEffect} from "react";
import { useNavigate } from 'react-router-dom';

export default function Home(){

    const navigate= useNavigate();

    const logout=()=>{
        navigate("/");
        sessionStorage.clear();
    }

    useEffect(()=>{
        if(sessionStorage.getItem("user")!=null) navigate("/home")
        else navigate("/");
    });

    return(<>
        <h1>Hello {sessionStorage.getItem("name")}</h1>
        <button onClick={logout}>Logout</button>
        </>
    );
}