import axios from 'axios';

export const dd= async()=>{
    return await axios.get("http://localhost:8080/students");
}

export const validateLogin= async(data)=>{
    return await axios.post("http://localhost:7000/verification",data);
}