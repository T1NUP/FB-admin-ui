import React from "react";
import {Form, Button} from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.css';
import './styles.css';
import { useState } from "react";
import { useNavigate } from 'react-router-dom';
import { validateLogin } from "../utils/ApiCalls";
import { useEffect } from "react";

export default function Login(){

    const navigate= useNavigate();

    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");

    const change=(event)=>{
        if(event.target.id=='username'){
            setUsername(event.target.value);
        }
        if(event.target.id=='password'){
            setPassword(event.target.value);
        }
    }

    const handleSubmit=()=>{
        console.log("SUB:::", username, password);
        let body={
            userName: username,
            password
        }
        validateLogin(body).then((res)=>{
            console.log("Da::", res);
           if(res.data.length!=0) {
            navigate("/home");
            sessionStorage.setItem("user",username);
            sessionStorage.setItem("name",res.data.name);
            sessionStorage.setItem("type",res.data.isAdmin);
           }
           else alert("Invalid Creds");
        });
        // navigate("/login");
    }

    // useEffect(()=>{
    //     if(sessionStorage.getItem("user")!=null) {}
    //     else navigate("/");
    // })

    return(<>
        <Form className="login">
            <h2>Login</h2>
                <Form.Group className="mb-3" controlId="formBasicEmail">
                    <Form.Label>Username</Form.Label>
                    <Form.Control id="username" type="text"  value={username} onChange={change}/>
                </Form.Group>
                <Form.Group className="mb-3" controlId="formBasicEmail">
                    <Form.Label>Password</Form.Label>
                    <Form.Control id="password" type="password" value={password} onChange={change} />
                </Form.Group>
                
        </Form>
        <Button variant="primary" type="submit" onClick={handleSubmit}>
        LOGIN
    </Button>&nbsp;&nbsp;&nbsp;
    <Button variant="secondary" type="submit" onClick={()=>(navigate("/register"))}>Register</Button>
    </>
    
    );
}