import React,{useEffect} from "react";
import { useNavigate } from 'react-router-dom';

export default function Admin(){

    const navigate= useNavigate();

    const logout=()=>{
        navigate("/");
        sessionStorage.clear();
    }

    useEffect(()=>{
        if(sessionStorage.getItem("type")==0) navigate("/home")
        else if(sessionStorage.getItem("type")==1) navigate("/admin")
        else navigate("/");
    });

    return(<>
        <h1>Hello Admin {sessionStorage.getItem("name")}</h1>
        <button onClick={logout}>Logout</button>
        </>
    );
}